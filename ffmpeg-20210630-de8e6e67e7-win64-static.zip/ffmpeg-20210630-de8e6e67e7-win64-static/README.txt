Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF 6898a97 Added optimized version of tiny-AES
aom 028d298a1 Correctly set delta_lf
AviSynthPlus 73e37e77 Recognize \'  \b and \v in escaped (e"somethg")  string literals
cargo-c bd11f6a Always use the /-separator
dav1d 3000045 x86: Add high bitdepth smooth ipred SSSE3 asm
ffmpeg de8e6e67e7 doc/muxers: note atomic_writing in image2
ffnvcodec 9939a5b Add more memory functions
flac 37d1a620 github actions: Fix typo.
fontconfig e291fda Bump version to 2.13.94
freetype2 6a2b3e400 * Version 2.10.4 released. ==========================
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz 096961486 [ot-shape] Rewrite loop without foreach_grapheme()
libaacs c0d5c14 aacs: error out after gcrypt AES error.
libass 4779444 ci: remove Travis
libavif 2dde71d Fix avifDecoderItemMaxExtent() - compensate for sample->offset correctly (#687)
libbdplus bd8c0dd configure.ac: use mingw as the case instead of mingw32
libbluray 311f0928 Bump version (1.3.0)
libmfx 0349e3b API 1.35
libmysofa d70a2a7 Fix for #158
librtmp f1b83c1 Fix race condition in the librtmp install target.
libsoxr 945b592 update NEWS, versions
libwebp 4de35f43 rescaler.c: fix alignment
libxml2 22f15211 Use version in configure.ac for CMake
openmpt 3b49d0935 [Mod] libopenmpt: Prepare for release.
opus 61747bc6 meson: fix get-version script for git worktrees
rav1e b0cb6679 CI: Update to libaom to 3.1.1-dmo0~bpo10+2
srt e932e8f [core] Fixed getTsbPdTimeBase: carryover within 2 wrapping periods (#2043)
SVT-AV1 44486d23 Static Analysis fixes (#1684)
vidstab 00e0841 Add GCC macros for byte order
vmaf eac6ddc7 libvmaf: add vmaf_feature_dictionary_free()
vpx fe1c7d2d8 Disallow skipping transform and quantization
x264 ae03d92b Add support for Sony XAVC Class 300 and 480
zimg 284c896 common: fix detection of Zen2 and add detection of Zen3



General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.