Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-librav1e
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF 2366f74 Revert README file.
aom 4782f340d Skip ForcedFrameIsKeyCornerCases for bug 2915
AviSynthPlus 187edc92 Merge branch 'master' of https://github.com/AviSynth/AviSynthPlus
cargo-c bf24d0f CI: Do not need to set MSVC path explicitly anymore
dav1d 7424f8e CI: Run multithreaded tests using thread sanitizer (tsan)
ffmpeg 477dd2df60 dnn_interface.h: fix redefining typedefs
ffnvcodec 315ad74 add cuMemcpy
flac bfd4f13f docs: fix simple typo, opertator -> operator
fontconfig d06103e Bump version to 2.13.93
freetype2 6a2b3e400 * Version 2.10.4 released. ==========================
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz 1fb7f3bd [docs] Document various HB_SCRIPT_*
libaacs 0c09c3f Simplify alloc size calculation
libass fba8af5 docs: fix simple typo, ouline -> outline
libavif f9fca86 Declare gridCols and gridRows as uint32_t
libbdplus e98c143 Update README and move to Markdown
libbluray a798b053 Add bd_event_name().
libmfx 2cd279f Merge pull request #81 from maximd33/master
libmysofa 20b8d1d Merge pull request #148 from hoene/ygrabit-warningsonly
librtmp c5f04a5 Reject Content-Length over 2^31
libsoxr 945b592 update NEWS, versions
libwebp 8df77fb1 animdecoder_fuzzer: fix memory leak
libxml2 79301d3d Fix timeout when handling recursive entities
openmpt 3f7268aec [Mod] libopenmpt: Prepare for release.
opus 794392ec ci: fix pipeline run for merge requests
rav1e f3304b07 CI: Use ilammy/setup-nasm@v1 to install nasm
srt df25ca8 [core] Minor warning fixes (C4267): type conversion with possible loss of data (#1710)
SVT-AV1 11d11c04 build.bat: add avx512 option
vidstab f9166e9 Merge pull request #100 from mannyamorim/master
vmaf 1a37e687 The wrong word was used. This has been corrected.
vpx 3a38edea2 Fix show_index in vp9_extrc_encodeframe_decision()
x264 8bd6d280 aarch64/asm: optimize cabac asm
x265_git 4e3bb4354 fix: avoids unnecessary lexicographic order checks on git changesets
zimg e17ee6c Update version to 3.0.1


General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.