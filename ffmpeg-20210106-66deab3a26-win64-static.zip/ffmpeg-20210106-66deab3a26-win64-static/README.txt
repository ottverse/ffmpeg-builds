Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-librav1e
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF 2366f74 Revert README file.
aom a268b8819 Consolidate ML based prune partition speed features
AviSynthPlus 88fb1cdf posix.rst: some long-needed updates for clarity
cargo-c bf24d0f CI: Do not need to set MSVC path explicitly anymore
dav1d 5dc55af SSE2, msac: Use bsr shortcut for 50% bool decoding
ffmpeg 66deab3a26 avformat/vividas: Check number of audio channels
ffnvcodec 315ad74 add cuMemcpy
flac bfd4f13f docs: fix simple typo, opertator -> operator
fontconfig d06103e Bump version to 2.13.93
freetype2 6a2b3e400 * Version 2.10.4 released. ==========================
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz c8c5e52a [use] Update overrides to 2021-01-04
libaacs 0c09c3f Simplify alloc size calculation
libass fba8af5 docs: fix simple typo, ouline -> outline
libavif 74afba3 Expose AOM specific film grain advanced options (#456)
libbdplus e98c143 Update README and move to Markdown
libbluray 24d38b8e Update check for new libudfread pkg-config file name
libmfx 2cd279f Merge pull request #81 from maximd33/master
libmysofa e93015e Merge pull request #154 from hoene/malloc-issues
librtmp c5f04a5 Reject Content-Length over 2^31
libsoxr 945b592 update NEWS, versions
libwebp 8df77fb1 animdecoder_fuzzer: fix memory leak
libxml2 79301d3d Fix timeout when handling recursive entities
openmpt 3f7268aec [Mod] libopenmpt: Prepare for release.
opus 794392ec ci: fix pipeline run for merge requests
rav1e 742c0fe8 CI: Remove a useless condition
srt df25ca8 [core] Minor warning fixes (C4267): type conversion with possible loss of data (#1710)
SVT-AV1 202950ab cppcheck: suppress unused functions and extra messages
vidstab f9166e9 Merge pull request #100 from mannyamorim/master
vmaf a6973369 Update ffmpeg.md
vpx 3a38edea2 Fix show_index in vp9_extrc_encodeframe_decision()
x264 8bd6d280 aarch64/asm: optimize cabac asm
x265_git 4e3bb4354 fix: avoids unnecessary lexicographic order checks on git changesets
zimg e17ee6c Update version to 3.0.1



General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.