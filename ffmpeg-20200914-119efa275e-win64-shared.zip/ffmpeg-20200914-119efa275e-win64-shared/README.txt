Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-librav1e
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF 802f92e Updated documentation
aom 59f113d3b Correct rd cost computation using RDCOST_DBL in hbd encode
AviSynthPlus f44a7c66 Update changelogs
cargo-c 26c42fa Prepare for release
curl 0c9211798 tiny-curl: 7.72.0 release
dav1d 8c2a897 cli: Add support for Unicode and long paths on Windows 10
ffmpeg 119efa275e avformat: add Argonaut Games BRP demuxer
ffnvcodec c928e22 Add linker functions and types
flac ce6dd6b5 CMake polishing
fontconfig b1df110 Bump version to 2.13.92
fribidi 5464c28 Bumped version to 1.0.10
gpac c6ca4f24d fixed crash introduced by prev commit
harfbuzz 8c3d4de7 [subset] Fix integer underflow in ContextFormat2.
libaacs 0c09c3f Simplify alloc size calculation
libass 42aa6ee ass.h: Mark deprecated declarations as deprecated
libavif 037b7bf Disable receiving one-frame-per-layer when decoding scalable AVIFs with aom and dav1d
libbdplus e98c143 Update README and move to Markdown
libbluray bc6150d2 FileInputStream: fix sign extended bytes in read()
libmfx 3ecc413 adjusted file attributes
libmysofa 6f4f25e Update README.md
librtmp c5f04a5 Reject Content-Length over 2^31
libsoxr 945b592 update NEWS, versions
libwebp cf847cba use WEBP_DSP_INIT_FUNC for Init{GammaTables*,GetCoeffs}
libxml2 b215c270 Fix cleanup of attributes in XML reader
libzen 14b165e Merge pull request #118 from g-maxime/osx-toolchain
openmpt 5c6c24339 [Mod] libopenmpt: Prepare for release.
opus 034c1b61 Fix MSVC warning about trunction from double to float
rav1e 92074b3a tiling: Determine tile_cols_log2 from selected column count
srt e756477 [core] Added connection callback, called when the async connection succeeds or fails (#1487)
SVT-AV1 1d3b6c60 Fix memory leaks from valgrind (#1481)
vidstab aeabc8d Merge pull request #72 from candrews/patch-3
vmaf 7ba6aac Misc.
vpx 478c70f6d googletest: enable failure on uninstantiated tests
x264 db0d4177 Rename function x264_strdup to x264_param_strdup
x265_git 6ed1c24a2 Add real-time VBV fullness based QP tuning in VBV 2 pass
zimg e17ee6c Update version to 3.0.1



General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.