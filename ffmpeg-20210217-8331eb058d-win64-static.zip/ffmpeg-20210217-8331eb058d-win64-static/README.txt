Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF c7f58ee D3D12 resource synchronization fence information moved to public header
aom fa301c776 Use RANGE_CHECK_HI on g_lag_in_frames, kf_max_dist
AviSynthPlus ae2e995f avisynth.h remove leftover INTEL_INTRINSICS. Warnings
cargo-c 1e74bcf Update README.md
dav1d 1d6aae4 build: Fix compilation with clang-cl
ffmpeg 8331eb058d avformat/ircamdec: use lrintf() for rounding
ffnvcodec 315ad74 add cuMemcpy
flac bfd4f13f docs: fix simple typo, opertator -> operator
fontconfig d06103e Bump version to 2.13.93
freetype2 6a2b3e400 * Version 2.10.4 released. ==========================
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz cd08c2528 Fix typo
libaacs d792013 Silence warning
libass d0634f4 ci: add Coverity to GHA
libavif 5c1577e ext/svt.sh: Checkout SVT-AV1 v0.8.6
libbdplus bd3e879 CI: Updated to use modern builders
libbluray 79429a52 Add player setting for JAVA_HOME.
libmfx 25bde3f API 1.34
libmysofa 8dda834 Fix coverity warning
librtmp c5f04a5 Reject Content-Length over 2^31
libsoxr 945b592 update NEWS, versions
libwebp 26907822 pngdec: check version before using png_get_chunk_malloc_max
libxml2 cbe1212d Fix null deref introduced with previous commit
openmpt 6531daefb [Mod] libopenmpt: Prepare for release.
opus d633f523 Fix float-approx negative left shift UB
rav1e e9be6c95 Tune flow of inline methods in symbol_with_update
srt 3754562 [core] Created internal config storage for a socket (#1776)
SVT-AV1 44486d23 Static Analysis fixes (#1684)
vidstab 00e0841 Add GCC macros for byte order
vmaf ab8eabab Update datasets.md
vpx 24bd0733e vp8_denoiser_sse2_test: disable BitexactCheck w/gcc-8+
x264 b86ae3c6 x86inc: Add stack probing on Windows
x265_git b24459657 analysis-save/load: update doc and regression CLI's for reusing cutree info in reuse-levels >= 2
zimg c0d9c49 Update checked_int library



General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.