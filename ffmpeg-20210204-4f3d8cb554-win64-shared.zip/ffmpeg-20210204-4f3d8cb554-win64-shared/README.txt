Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF e4a58cf Two minor fixes (#251)
aom 156267a2b Remove extra best_coeff from mode_estimation
AviSynthPlus 41a12933 avisynth.cpp: use PAGESIZE instead of hardcoded value on Haiku
cargo-c 1e74bcf Update README.md
dav1d 6660fd0 looprestoration: Document how much filters are allowed to write past the right edge
ffmpeg 4f3d8cb554 avcodec/cabac_functions, x86/cabac: Include stddef.h
ffnvcodec 315ad74 add cuMemcpy
flac bfd4f13f docs: fix simple typo, opertator -> operator
fontconfig d06103e Bump version to 2.13.93
freetype2 6a2b3e400 * Version 2.10.4 released. ==========================
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz 99184fbe [ci] Add top level directory to win32 zip file
libaacs d792013 Silence warning
libass d1903f5 fontselect: warn when no fallback can be found
libavif be4a213 Add limited/full testing and full CICP specifying to avifyuv's drift mode (#473)
libbdplus bd3e879 CI: Updated to use modern builders
libbluray 9f1cc143 BDJ: Try to disable headless autoprobing.
libmfx 25bde3f API 1.34
libmysofa 8dda834 Fix coverity warning
librtmp c5f04a5 Reject Content-Length over 2^31
libsoxr 945b592 update NEWS, versions
libwebp 47f64f6e filters_sse2: import Chromium change
libxml2 acb35667 Fix quadratic runtime when parsing CDATA sections
openmpt 6531daefb [Mod] libopenmpt: Prepare for release.
opus d633f523 Fix float-approx negative left shift UB
rav1e 61133e34 Add missing macro calls for symbol_with_update
srt 5ec84d2 [core] Fixed faulty packet drop by a group. m_RcvBaseSeqNo must be updated only when a packet is read. However, it could have been updated also when only checked.
SVT-AV1 ec7ac87f CMake: fix COVERAGE option (#1682)
vidstab 00e0841 Add GCC macros for byte order
vmaf bf5e496c Move 5PL_v1.py from root to resource/model_param.
vpx 158aa20c9 svc: Unittest for ksvc flexible mode with no updates on TL > 0
x264 59c06095 x86inc: Fix LOAD_MM_PERMUTATION for AVX-512
x265_git 681c05e83 introduction.rst edited online with Bitbucket
zimg c0d9c49 Update checked_int library



General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.