Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-librav1e
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF 802f92e Updated documentation
aom f88a15172 Added links to AV1 technical overview document
AviSynthPlus c377916a Update changelog
cargo-c e569550 example project: remove header sub-directory
dav1d 901704e Avoid using %ld for debugging in obu.c
ffmpeg 289e964873 avcodec/vp3: Unify initializing and freeing VLC tables
ffnvcodec 7a81595 Update headers from Video SDK 11.0
flac ce6dd6b5 CMake polishing
fontconfig b1df110 Bump version to 2.13.92
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz 49ebb9eb [use] Remove redundant O entries from the table
libaacs 0c09c3f Simplify alloc size calculation
libass 0aec12b Fix Scroll effects with rectangle \clip/\iclip
libavif 3f2bf95 Link with {ZLIB_LIBRARY} after ${PNG_LIBRARY}
libbdplus e98c143 Update README and move to Markdown
libbluray 1ce479c1 Fix long delay in "Evangelion, You are (not) alone" menu
libmfx 2cd279f Merge pull request #81 from maximd33/master
libmysofa 6f4f25e Update README.md
librtmp c5f04a5 Reject Content-Length over 2^31
libsoxr 945b592 update NEWS, versions
libwebp eb44119c Merge changes I8ae09473,I678c8b1e
libxml2 b46016b8 Allow port numbers up to INT_MAX
openmpt 5c6c24339 [Mod] libopenmpt: Prepare for release.
opus 034c1b61 Fix MSVC warning about trunction from double to float
rav1e 3a1cc6b7 CI: Avoid deploying automatically binaries on forks
srt f821125 [docs] Improved latency description in APISocketOptions (#1607)
SVT-AV1 80ec5ae7 2pass: initial data rate control options (#1542)
vidstab e851e7b Revert "Merge pull request #91 from 1480c1/openmp"
vmaf 2cd138c build: unbreak x86 builds
vpx 13aad8bb6 Merge "Add unit test for vp9_ext_ratectrl"
x264 db0d4177 Rename function x264_strdup to x264_param_strdup
x265_git a82c6c7a7 analysis-save/load: Enable reuse of cutree info in reuse-levels >= 2
zimg e17ee6c Update version to 3.0.1





General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.