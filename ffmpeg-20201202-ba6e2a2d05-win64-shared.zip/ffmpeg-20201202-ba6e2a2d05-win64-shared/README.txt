Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-librav1e
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF 7a83513 Update README.md
aom cdb62d54e Fix array bound warning in transpose ssse3
AviSynthPlus 69755f54 Update changelog
cargo-c c2a1904 Do not mention cfg(cargo_c)
dav1d d6beb0a meson: Support running checkasm benchmarks through meson
ffmpeg ba6e2a2d05 avfilter/af_acrossover: move coefficients and state to simple arrays
ffnvcodec 315ad74 add cuMemcpy
flac ce6dd6b5 CMake polishing
fontconfig d06103e Bump version to 2.13.93
freetype2 6a2b3e400 * Version 2.10.4 released. ==========================
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz 07e304b2 Merge pull request #2755 from Myaamori/master
libaacs 0c09c3f Simplify alloc size calculation
libavif f8d9b83 Add the avifContainerDump() function
libbdplus e98c143 Update README and move to Markdown
libbluray a798b053 Add bd_event_name().
libmfx 2cd279f Merge pull request #81 from maximd33/master
libmysofa bc59686 Merge pull request #146 from hoene/issue-137-zero-attribute
librtmp c5f04a5 Reject Content-Length over 2^31
libsoxr 945b592 update NEWS, versions
libwebp 7656f0b3 README,cosmetics: fix a couple typos
libxml2 1c4f9a6d Require dependencies based on enabled CMake options
openmpt 3f7268aec [Mod] libopenmpt: Prepare for release.
opus d2f6805c Meson: Fix doc build when opus is a subproject
rav1e b2fe4067 arm32: mc: NEON implementation of warp8x8 for 16 bpc
srt c42bc13 [core] A change in setupCC to access CUnitQueue via CRcvQueue instead of CRcvBuffer (#1681)
SVT-AV1 a5ec26c0 New rev increment v0.8.6 (#1610)
vidstab f9166e9 Merge pull request #100 from mannyamorim/master
vmaf 27ed7861 path error
vpx ebac57ce9 Fix typos in simple_encode.h
x264 4121277b Add a missing include of stdlib.h
x265_git 5163c32d7 readme.rst : Update broken links
zimg e17ee6c Update version to 3.0.1








General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.