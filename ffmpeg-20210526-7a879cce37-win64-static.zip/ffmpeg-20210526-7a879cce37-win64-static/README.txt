Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF 6898a97 Added optimized version of tiny-AES
aom be8ccad71 FPMT: Abstract mv_stats to AV1_PRIMARY
AviSynthPlus e18e487c Update readmes
cargo-c cce1b08 Prepare for release
dav1d c389d89 arm64: filmgrain: Fix overflows in gen_grain
ffmpeg 7a879cce37 libavfilter: vf_drawtext filter support draw text with detection bounding boxes in side_data
ffnvcodec 7adf160 Bump for (in-dev) 11.0.10.2
flac 27c61570 github actions: Drop HTML validation
fontconfig d06103e Bump version to 2.13.93
freetype2 6a2b3e400 * Version 2.10.4 released. ==========================
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz 1dffb5536 Chromium build fixes for C++ 17 warning and missing _remap_indexes
libaacs c0d5c14 aacs: error out after gcrypt AES error.
libass b9f3468 directwrite: add whole font family from `match_fonts`
libavif 83d597c Move svt update changelog entry into Unreleased (v0.9.1 is already done), remove extraneous newline
libbdplus bd8c0dd configure.ac: use mingw as the case instead of mingw32
libbluray 311f0928 Bump version (1.3.0)
libmfx 25bde3f API 1.34
libmysofa d70a2a7 Fix for #158
librtmp f1b83c1 Fix race condition in the librtmp install target.
libsoxr 945b592 update NEWS, versions
libwebp afbca5a1 Require Emscripten 2.0.18
libxml2 13ad8736 Fix regression in xmlNodeDumpOutputInternal
openmpt 3b49d0935 [Mod] libopenmpt: Prepare for release.
opus dfd6c88a cmake - add support to run ctest on android #2347
rav1e a3badce7 Resolve an unnecessary clone of rec data (#2741)
srt 22cc924 [core] Applied clang-format on channel.h and cpp
SVT-AV1 44486d23 Static Analysis fixes (#1684)
vidstab 00e0841 Add GCC macros for byte order
vmaf e86a6801 Add feature_opts_dicts to TrainTestModel model output.
vpx dbda032fc Use 'ptrdiff_t' instead of 'int' for pointer offset parameters
x264 b684ebe0 Cosmetics: Fix vertical alignment for long_options
zimg 55a0f1f graph: fix fullrange grey to RGB conversion



General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.