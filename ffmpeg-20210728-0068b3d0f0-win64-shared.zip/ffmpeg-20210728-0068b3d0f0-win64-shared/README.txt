Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF 3ee61d7 Updated to the latest 1.4.21
aom 0d7c46cf5 Rework superblock and frame normalization for deltaq
AviSynthPlus 5c050fdc Expr: fix recent; use c_str, not string
cargo-c 5b17573 Prepare for release
dav1d c719d4a x86/filmgrain: add fguv_32x32xn_i444 HBD/AVX2
ffmpeg 0068b3d0f0 avfilter/avf_showcqt: switch to TX FFT from avutil
ffnvcodec 9939a5b Add more memory functions
flac b358381a cpu.h: detect AVX/FMA intrinsics availability on clang
fontconfig e291fda Bump version to 2.13.94
freetype2 801cd842e * Version 2.11.0 released. ==========================
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz ad9559e3e [tests] Make AOTS update.py work on macOS
libaacs c0d5c14 aacs: error out after gcrypt AES error.
libass 5733e1c ass_face_stream: don't leak first struct if second alloc fails
libavif 1556f21 In 32-bit builds set frame_size_limit to 8192*8192
libbdplus bd8c0dd configure.ac: use mingw as the case instead of mingw32
libbluray 311f0928 Bump version (1.3.0)
libmfx 0349e3b API 1.35
libmysofa fc9e9ac CMake: Install import library for shared build
librtmp f1b83c1 Fix race condition in the librtmp install target.
libsoxr 945b592 update NEWS, versions
libwebp 1fe31625 dsp/*: use WEBP_HAVE_* to determine Init availability
libxml2 dea91c97 Fix buffering in xmlOutputBufferWrite
openmpt 44733ab3d [Mod] libopenmpt: Prepare for release.
opus 6b6035ae Remove an unused parameter
rav1e f6c841fe CI: Update to libaom to 3.1.2-dmo1
srt ea4edff [core] Moved compiler attribute definitions
SVT-AV1 44486d23 Static Analysis fixes (#1684)
vidstab 00e0841 Add GCC macros for byte order
vmaf 60b2469e add ci job to validate docker build
vpx fc04a9491 Fix some instances of -Wunused-but-set-variable.
x264 ae03d92b Add support for Sony XAVC Class 300 and 480
zimg 9cf3de9 github: disable Clang sanitizers due to OOM






General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.