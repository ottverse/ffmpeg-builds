Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF 6898a97 Added optimized version of tiny-AES
aom 36c2b994b Add an option to disable transform search size.
AviSynthPlus 8cbf9827 pkg-config: use prefix for includedir instead of exec_prefix
cargo-c 03677d1 Prepare for release
dav1d e4812a6 x86: itx4: Inline transpose
ffmpeg 947122f111 libavfilter: Fix fate-source after 072788c46e36a21ca9e8f1e3cc19a1944db5b89c
ffnvcodec 6837c4d Fix UB lshift in nvenc struct version macros
flac eba0ff8d CI: Run on pull requests and once a month
fontconfig d06103e Bump version to 2.13.93
freetype2 6a2b3e400 * Version 2.10.4 released. ==========================
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz cc9bb2949 [blob] Fix-up recent mistake in hb_blob_create() destroy(user_data)
libaacs c0d5c14 aacs: error out after gcrypt AES error.
libass 4779444 ci: remove Travis
libavif 26c7ed6 Don't need to disable MSVC warnings 5031 and 5032
libbdplus bd8c0dd configure.ac: use mingw as the case instead of mingw32
libbluray 311f0928 Bump version (1.3.0)
libmfx 25bde3f API 1.34
libmysofa d70a2a7 Fix for #158
librtmp f1b83c1 Fix race condition in the librtmp install target.
libsoxr 945b592 update NEWS, versions
libwebp 6f445b3e CMake: set CMP0072 to NEW
libxml2 22f15211 Use version in configure.ac for CMake
openmpt 3b49d0935 [Mod] libopenmpt: Prepare for release.
opus 61747bc6 meson: fix get-version script for git worktrees
rav1e 685c3949 CI: Update libaom to 3.1.1-dmo0~bpo10+1
srt e932e8f [core] Fixed getTsbPdTimeBase: carryover within 2 wrapping periods (#2043)
SVT-AV1 44486d23 Static Analysis fixes (#1684)
vidstab 00e0841 Add GCC macros for byte order
vmaf 6308517d Feature/add scales to vif kernelscale (#877)
vpx a00c56373 rc: turn off gf constrain for external RC
x264 ae03d92b Add support for Sony XAVC Class 300 and 480
zimg a944ee4 common: fix detection of Zen2 and add detection of Zen3



General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.