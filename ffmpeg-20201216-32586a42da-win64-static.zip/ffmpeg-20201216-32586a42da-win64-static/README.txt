Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-librav1e
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF 7a83513 Update README.md
aom 54b684be7 Add SSE2 variant for MULTITAP_SHARP2 y-convolve
AviSynthPlus 187edc92 Merge branch 'master' of https://github.com/AviSynth/AviSynthPlus
cargo-c 376fdc1 Add a link to crates.io on the badge
dav1d ea65e1a meson: Increase checkasm timeout
ffmpeg 32586a42da avfilter/vf_limiter: add support for commands
ffnvcodec 315ad74 add cuMemcpy
flac ce6dd6b5 CMake polishing
fontconfig d06103e Bump version to 2.13.93
freetype2 6a2b3e400 * Version 2.10.4 released. ==========================
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz 2953a66a CMake: Define HAVE_GOBJECT when harfbuzz-gobject is built
libaacs 0c09c3f Simplify alloc size calculation
libavif 2b7f04e Fix -Wmissing-prototypes and -Wcast-qual warnings
libbdplus e98c143 Update README and move to Markdown
libbluray a798b053 Add bd_event_name().
libmfx 2cd279f Merge pull request #81 from maximd33/master
libmysofa bc59686 Merge pull request #146 from hoene/issue-137-zero-attribute
librtmp c5f04a5 Reject Content-Length over 2^31
libsoxr 945b592 update NEWS, versions
libwebp 2e7bed79 WebPPicture: clarify the ownership of user-owned data.
libxml2 8ca3a59b Fix integer overflow in xmlSchemaGetParticleTotalRangeMin
openmpt 3f7268aec [Mod] libopenmpt: Prepare for release.
opus a923218e docs: fix simple typo, neareast -> nearest
rav1e 5caffedb Add LICENSE file to v_frame
srt c507c5b [tests] Fixed connection timeout test to not reuse broken socket (#1712)
SVT-AV1 f5a7e8f1 stylecheck.sh: add a warning for any fixup commits
vidstab f9166e9 Merge pull request #100 from mannyamorim/master
vmaf a833820f Update vmaf_4k_v0.6.1.json to use integer features (addressing #759).
vpx 2392fe53a Merge "configure: add darwin20 cross-compile support"
x264 4121277b Add a missing include of stdlib.h
x265_git d926c0203 Fix version information reporting for x265 git archival
zimg e17ee6c Update version to 3.0.1









General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.