Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF c7f58ee D3D12 resource synchronization fence information moved to public header
aom 41fd15c9c Allow updates of motion costs for intrabc
AviSynthPlus 989c76d6 Make static linking work in Windows
cargo-c a207f85 Rename link_args to rustc_args
dav1d 6c6d25d arm64: Add NEON implementation of fgy_32x32xn
ffmpeg 9383885c0d avformat/aviobuf: don't reduce short seek threshold
ffnvcodec 315ad74 add cuMemcpy
flac 27c61570 github actions: Drop HTML validation
fontconfig d06103e Bump version to 2.13.93
freetype2 6a2b3e400 * Version 2.10.4 released. ==========================
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz 03538e872 2.8.0
libaacs d792013 Silence warning
libass 0a3b14a be_padding: pad enough for intermediate states, not only result
libavif db1009a Code analysis cleanup (MS CL)
libbdplus bd3e879 CI: Updated to use modern builders
libbluray 79429a52 Add player setting for JAVA_HOME.
libmfx 25bde3f API 1.34
libmysofa 5a2cf57 CID 1502678:   Control flow issues   (NO_EFFECT)
librtmp f1b83c1 Fix race condition in the librtmp install target.
libsoxr 945b592 update NEWS, versions
libwebp 25ae67b3 xcframeworkbuild.sh: add arm64 simulator target
libxml2 868e49cf Allow FP division by zero in xmlXPathInit
openmpt bcee07d7e [Mod] libopenmpt: Prepare for release.
opus 7b05f44f celt_lpc: avoid overflows when computing lpcs in fixed point
rav1e 87c0297c Bump pretty_assertion
srt 3605f6f [core] Removed condition that blocks extending group HS extension in future
SVT-AV1 44486d23 Static Analysis fixes (#1684)
vidstab 00e0841 Add GCC macros for byte order
vmaf 6f1f0c98 Misc.
vpx 973726c38 vp9-rtc: Add postencode_drop control to sample encoder
x264 b86ae3c6 x86inc: Add stack probing on Windows
x265_git ce882936d Update x265Version.txt
zimg c0d9c49 Update checked_int library




General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.