Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF c7f58ee D3D12 resource synchronization fence information moved to public header
aom 82e76bdd6 aom_dsp: Fix aom_noise_strength_lut_init with negative size
AviSynthPlus 989c76d6 Make static linking work in Windows
cargo-c 3dc0c1e Always set the target triple
dav1d 6c6d25d arm64: Add NEON implementation of fgy_32x32xn
ffmpeg dfad5794fb avformat/amvenc: Remove unnecessary av_packet_free()
ffnvcodec 315ad74 add cuMemcpy
flac 27c61570 github actions: Drop HTML validation
fontconfig d06103e Bump version to 2.13.93
freetype2 6a2b3e400 * Version 2.10.4 released. ==========================
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz 29708e959 [aat] Fix offsetToIndex math for out-of-bounds values
libaacs d792013 Silence warning
libass 0a3b14a be_padding: pad enough for intermediate states, not only result
libavif dfa2f0a Additional fixes for PR #530
libbdplus bd3e879 CI: Updated to use modern builders
libbluray 79429a52 Add player setting for JAVA_HOME.
libmfx 25bde3f API 1.34
libmysofa 5a2cf57 CID 1502678:   Control flow issues   (NO_EFFECT)
librtmp f1b83c1 Fix race condition in the librtmp install target.
libsoxr 945b592 update NEWS, versions
libwebp 25ae67b3 xcframeworkbuild.sh: add arm64 simulator target
libxml2 fb08d9fe Fix include order in c14n.h
openmpt 3b6b29ea8 [Mod] libopenmpt: Prepare for release.
opus 7b05f44f celt_lpc: avoid overflows when computing lpcs in fixed point
rav1e c474d191 Move the tiling info logging outside the internals
srt 93de9c8 [core] Removed unnecessary lock that could cause a deadlock
SVT-AV1 44486d23 Static Analysis fixes (#1684)
vidstab 00e0841 Add GCC macros for byte order
vmaf c8e367d8 libvmaf: fix FILE* leaks when reading model json
vpx b5e754a84 Change SR_diff calculation and representation
x264 b86ae3c6 x86inc: Add stack probing on Windows
x265_git ce882936d Update x265Version.txt
zimg c0d9c49 Update checked_int library





General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.