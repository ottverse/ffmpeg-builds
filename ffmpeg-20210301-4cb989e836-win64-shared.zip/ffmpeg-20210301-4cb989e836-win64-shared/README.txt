Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF c7f58ee D3D12 resource synchronization fence information moved to public header
aom 4c40055ca Fix a speed issue in CONFIG_TUNE_BUTTERAUGLI
AviSynthPlus 989c76d6 Make static linking work in Windows
cargo-c a207f85 Rename link_args to rustc_args
dav1d f06148e Final update for 0.8.2 NEWS
ffmpeg 4cb989e836 avcodec/exr: add fast path for case when powf() isn't needed
ffnvcodec 315ad74 add cuMemcpy
flac bfd4f13f docs: fix simple typo, opertator -> operator
fontconfig d06103e Bump version to 2.13.93
freetype2 6a2b3e400 * Version 2.10.4 released. ==========================
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz 486da35cc m Add comments to IntType cast out operator
libaacs d792013 Silence warning
libass 8f98771 Fix crash on empty strings
libavif 4f40299 Fail on reformat Identity with subsampling, make avifenc correct this before reformat (#517)
libbdplus bd3e879 CI: Updated to use modern builders
libbluray 79429a52 Add player setting for JAVA_HOME.
libmfx 25bde3f API 1.34
libmysofa 8dda834 Fix coverity warning
librtmp f1b83c1 Fix race condition in the librtmp install target.
libsoxr 945b592 update NEWS, versions
libwebp 01b38ee1 faster CollectColorXXXTransforms_SSE41
libxml2 ce2fbaa8 Only run a few CI tests unless scheduled
openmpt 6531daefb [Mod] libopenmpt: Prepare for release.
opus 16286a25 Sending refresh DTX packets every 400 ms independently of the encoded frame size.
rav1e d6ab5ec8 x86: Use 'test' instead of 'or' to compare with zero
srt 6254c1d [tests] A basic check for initial group stats values
SVT-AV1 44486d23 Static Analysis fixes (#1684)
vidstab 00e0841 Add GCC macros for byte order
vmaf 6e9aba56 Misc.
vpx ebefb90b7 Remove comments for removed 'active_map' parameter
x264 b86ae3c6 x86inc: Add stack probing on Windows
x265_git b24459657 analysis-save/load: update doc and regression CLI's for reusing cutree info in reuse-levels >= 2
zimg c0d9c49 Update checked_int library



General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.