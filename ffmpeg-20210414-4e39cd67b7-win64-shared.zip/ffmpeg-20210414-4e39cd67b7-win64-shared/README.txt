Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF c7f58ee D3D12 resource synchronization fence information moved to public header
aom 5c9bc4181 Convert input frames to monochrome before encoding
AviSynthPlus e18e487c Update readmes
cargo-c 196ed9a Update readme again
dav1d ae8958b CI: Fix asm checks
ffmpeg 4e39cd67b7 fftools/ffmpeg_filter: Fix check for mjpeg encoder
ffnvcodec 315ad74 add cuMemcpy
flac 27c61570 github actions: Drop HTML validation
fontconfig d06103e Bump version to 2.13.93
freetype2 6a2b3e400 * Version 2.10.4 released. ==========================
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz 668acff1f similarly improve comments on Hebrew ccc 18 & 19
libaacs b84831e configure.ac: use mingw as the case instead of mingw32
libass 49f116a quantize_transform: Reword explanatory comment
libavif f8b2362 Add rav1e to AppVeyor builds
libbdplus bd8c0dd configure.ac: use mingw as the case instead of mingw32
libbluray 311f0928 Bump version (1.3.0)
libmfx 25bde3f API 1.34
libmysofa 5a2cf57 CID 1502678:   Control flow issues   (NO_EFFECT)
librtmp f1b83c1 Fix race condition in the librtmp install target.
libsoxr 945b592 update NEWS, versions
libwebp 7e58a1a2 *.cmake: add license header
libxml2 fb08d9fe Fix include order in c14n.h
openmpt e226c25a6 [Mod] libopenmpt: Prepare for release.
opus 7b05f44f celt_lpc: avoid overflows when computing lpcs in fixed point
rav1e 02106e0b CI: Update to libaom3 for both travis and GitHub Actions
srt 9e6c90f [core] Minor refactoring around ACK processing (#1928)
SVT-AV1 44486d23 Static Analysis fixes (#1684)
vidstab 00e0841 Add GCC macros for byte order
vmaf 771cec3c Feature/generalize transform score for piecewise linear mapping (#853)
vpx c77a7f600 Removed unused constant
x264 c347e7a0 CI: Add macos-arm64 target (cross-compile)
x265_git bf91444e0 Add: End Of Bitstream and End Of Sequence NAL units
zimg c0d9c49 Update checked_int library







General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.