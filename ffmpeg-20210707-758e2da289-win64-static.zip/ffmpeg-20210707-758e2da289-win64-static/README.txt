Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF 6898a97 Added optimized version of tiny-AES
aom 881cdf9ed FPMT: Initialize ref_idx_to_skip for parallel frames
AviSynthPlus 3a9e2c52 Update changelog
cargo-c 5b17573 Prepare for release
dav1d 33180d8 x86/deblock: make hbd/ssse3 implementations 32bit-compatible
ffmpeg 758e2da289 avfilter/f_metadata: do not return the frame early if there is no metadata
ffnvcodec 9939a5b Add more memory functions
flac 37d1a620 github actions: Fix typo.
fontconfig e291fda Bump version to 2.13.94
freetype2 6a2b3e400 * Version 2.10.4 released. ==========================
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz 895acdf7c [ci] Don’t build Cairo subproject with FontConfig on win32 cross-build
libaacs c0d5c14 aacs: error out after gcrypt AES error.
libass 856824f ci/gha: add musl build
libavif db27590 Bump of version in CMakeLists.txt was forgotten
libbdplus bd8c0dd configure.ac: use mingw as the case instead of mingw32
libbluray 311f0928 Bump version (1.3.0)
libmfx 0349e3b API 1.35
libmysofa fc9e9ac CMake: Install import library for shared build
librtmp f1b83c1 Fix race condition in the librtmp install target.
libsoxr 945b592 update NEWS, versions
libwebp 4de35f43 rescaler.c: fix alignment
libxml2 ec6e3efb Patch to forbid epsilon-reduction of final states
openmpt 44733ab3d [Mod] libopenmpt: Prepare for release.
opus 61747bc6 meson: fix get-version script for git worktrees
rav1e b0cb6679 CI: Update to libaom to 3.1.1-dmo0~bpo10+2
srt e932e8f [core] Fixed getTsbPdTimeBase: carryover within 2 wrapping periods (#2043)
SVT-AV1 44486d23 Static Analysis fixes (#1684)
vidstab 00e0841 Add GCC macros for byte order
vmaf 0511e053 vmaf/aom_ctc: add v2.0 preset option
vpx c64022fa3 Add codec control to get loopfilter level
x264 ae03d92b Add support for Sony XAVC Class 300 and 480
zimg bf73dbe Update ChangeLog



General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.