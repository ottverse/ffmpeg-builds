Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF 6898a97 Added optimized version of tiny-AES
aom 2d4bb0efd Add RD_COMMAND for rdmult experiment
AviSynthPlus c5af30d9 files.cmake comment for overlay multiply
cargo-c 14ba33b Update README.md
dav1d 185194b checkasm: Make sure that all pixels are in range before benchmarking
ffmpeg e01bf559df lavfi/vf_drawtext.c: fix CID 1485003
ffnvcodec 6837c4d Fix UB lshift in nvenc struct version macros
flac 27c61570 github actions: Drop HTML validation
fontconfig d06103e Bump version to 2.13.93
freetype2 6a2b3e400 * Version 2.10.4 released. ==========================
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz 4811e8f5d Trigger doc rebuild
libaacs c0d5c14 aacs: error out after gcrypt AES error.
libass 6fc9855 fontselect, coretext: match whole extended family on fallback
libavif 573815b Cleanup related to avifDiagnosticsClearError()
libbdplus bd8c0dd configure.ac: use mingw as the case instead of mingw32
libbluray 311f0928 Bump version (1.3.0)
libmfx 25bde3f API 1.34
libmysofa d70a2a7 Fix for #158
librtmp f1b83c1 Fix race condition in the librtmp install target.
libsoxr 945b592 update NEWS, versions
libwebp afbca5a1 Require Emscripten 2.0.18
libxml2 22f15211 Use version in configure.ac for CMake
openmpt 3b49d0935 [Mod] libopenmpt: Prepare for release.
opus 4b21ff9c Relax comparison to 0 to avoid a floating point divide-by-zero error.
rav1e 1c8ad5b1 Use the x86 8-bit CDEF assembly on edges
srt e761745 [tests] Added fixes for FEC test occasional failure (#2037)
SVT-AV1 44486d23 Static Analysis fixes (#1684)
vidstab 00e0841 Add GCC macros for byte order
vmaf 2693324e Add mirror methods to fix NorefAsset issues.
vpx b8273e8ae Fix simple encode
x264 b684ebe0 Cosmetics: Fix vertical alignment for long_options
zimg 7099df7 graph: set default CPU type to AUTO





General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.