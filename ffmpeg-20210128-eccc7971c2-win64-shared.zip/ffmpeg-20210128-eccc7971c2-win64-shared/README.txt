Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF e4a58cf Two minor fixes (#251)
aom 4c245093f Remove unused structures from encodetxb.c/.h
AviSynthPlus 41a12933 avisynth.cpp: use PAGESIZE instead of hardcoded value on Haiku
cargo-c 93f4b9f Prepare for release
dav1d ecb0074 data: Remove dead code
ffmpeg eccc7971c2 dnn_backend_openvino.c: remove extra semicolon
ffnvcodec 315ad74 add cuMemcpy
flac bfd4f13f docs: fix simple typo, opertator -> operator
fontconfig d06103e Bump version to 2.13.93
freetype2 6a2b3e400 * Version 2.10.4 released.
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz f94bf9f0 [set fuzzer] limit the total number of set members in a fuzzing input. Currently the fuzzer can create arbitarily long inputs which once big enough will trigger a timeout.
libaacs d792013 Silence warning
libass d1903f5 fontselect: warn when no fallback can be found
libavif 82d720e ext/libgav1.cmd: sync to 4a89dc3, update abseil-cpp
libbdplus bd3e879 CI: Updated to use modern builders
libbluray e5039092 Fix CI tags for win32
libmfx 25bde3f API 1.34
libmysofa 8dda834 Fix coverity warning
librtmp c5f04a5 Reject Content-Length over 2^31
libsoxr 945b592 update NEWS, versions
libwebp ceddb5fc Fix check_c_source_compiles with pthread.
libxml2 f93ca3e1 Update minimum required CMake version
openmpt 3f7268aec [Mod] libopenmpt: Prepare for release.
opus d633f523 Fix float-approx negative left shift UB
rav1e b1ccd634 Reject mismatched color configurations
srt 0f8623e [core] Fixed too early closed caller socket in background. (#1750)
SVT-AV1 82da6a8e remove blank UT
vidstab 00e0841 Add GCC macros for byte order
vmaf 278b946f Misc.
vpx f46b66ac8 svc: turn off use_base_mv on non base layer.
x264 b3aadb76 Fix PADH alignment
x265_git 681c05e83 introduction.rst edited online with Bitbucket
zimg c0d9c49 Update checked_int library




General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.