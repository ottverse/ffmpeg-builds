Downloaded from OTTVerse.com <https://ottverse.com/ffmpeg-builds> 


Configuration Settings 
====================== 
--disable-autodetect 
--enable-amf 
--enable-bzlib 
--enable-cuda 
--enable-cuvid 
--enable-d3d11va 
--enable-dxva2 
--enable-iconv 
--enable-lzma 
--enable-nvenc
--enable-zlib
--enable-sdl2
--enable-ffnvcodec
--enable-nvdec
--enable-cuda-llvm
--enable-libmp3lame
--enable-libopus
--enable-libvorbis
--enable-libvpx
--enable-libx264
--enable-libx265
--enable-libdav1d
--enable-libaom
--disable-debug
--enable-fontconfig
--enable-libass
--enable-libbluray
--enable-libfreetype
--enable-libmfx
--enable-libmysofa
--enable-libopencore-amrnb
--enable-libopencore-amrwb
--enable-libopenjpeg
--enable-libsnappy
--enable-libsoxr
--enable-libspeex
--enable-libtheora
--enable-libtwolame
--enable-libvidstab
--enable-libvo-amrwbenc
--enable-libwavpack
--enable-libwebp
--enable-libxml2
--enable-libzimg
--enable-libshine
--enable-gpl
--enable-avisynth
--enable-libxvid
--enable-libopenmpt
--enable-version3
--enable-librav1e
--enable-libsrt
--enable-libgsm
--enable-libvmaf
--enable-libsvtav1
--enable-librtmp
--enable-mbedtls
--extra-cflags=-DLIBTWOLAME_STATIC
--extra-libs=-lstdc++
--extra-cflags=-DLIBXML_STATIC
--extra-libs=-liconv
--disable-w32threads



Revisions Used
==============
AMF 802f92e Updated documentation
aom 8831b0e34 Fix a compilation error in Visual Studio
AviSynthPlus c377916a Update changelog
cargo-c b23e965 Do not build openssl by default
dav1d a40d3b5 Abort frame decoding properly on reference error
ffmpeg e5be4c5a88 avcodec/hevcdec: constrained intra predict, do not check top left IS_INTRA if it's not available
ffnvcodec 7a81595 Update headers from Video SDK 11.0
flac ce6dd6b5 CMake polishing
fontconfig b1df110 Bump version to 2.13.92
fribidi 5464c28 Bumped version to 1.0.10
harfbuzz 5091ea7e Merge pull request #2733 from astiob/buffer-context-doc
libaacs 0c09c3f Simplify alloc size calculation
libass 0171374 decode_font: fix subtraction broken by change to unsigned type
libavif ac4b18a Add additional libyuv fast paths
libbdplus e98c143 Update README and move to Markdown
libbluray a798b053 Add bd_event_name().
libmfx 2cd279f Merge pull request #81 from maximd33/master
libmysofa 6f4f25e Update README.md
librtmp c5f04a5 Reject Content-Length over 2^31
libsoxr 945b592 update NEWS, versions
libwebp 411d3677 remove some unreachable break statements
libxml2 7d6837ba Fix caret in regexp character group
openmpt 6b6a1a9a9 [Mod] libopenmpt: Prepare for release.
opus 034c1b61 Fix MSVC warning about trunction from double to float
rav1e 8973fd6d Bump cfg-if to 1.0
srt 7848fcd [docs] Added lacking description for grpdata field in SRT_MSGCTRL (#1623)
vidstab e851e7b Revert "Merge pull request #91 from 1480c1/openmp"
vmaf cbee5eb ci/macos: homebrew bug, workaround
vpx 89ddf6f32 vp9_ext_ratectrl_test: add missing override
x264 4121277b Add a missing include of stdlib.h
x265_git 5163c32d7 readme.rst : Update broken links
zimg e17ee6c Update version to 3.0.1





General Notice
===============
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.